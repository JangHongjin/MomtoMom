-- momuser insert[user 정보 저장]
insert into momuser values('momuser1', 'example1@naver.com', '1230', '20170101', 'ktds', 'manager', '01012341111', '1');
insert into momuser values('momuser2', 'example2@naver.com', '1230', '20170102', 'ktds', 'manager', '01012342222', '1');
insert into momuser values('momuser3', 'example3@naver.com', '1230', '20170103', 'ktds', 'manager', '01012343333', '1');
insert into momuser values('momuser4', 'example4@naver.com', '1230', '20170104', 'ktds', 'manager', '01012344444', '1');
insert into momuser values('momuser5', 'example5@naver.com', '1230', '20170105', 'ktds', 'manager', '01012345555', '1');
insert into momuser values('momuser6', 'example6@naver.com', '1230', '20170106', 'ktds', 'manager', '01012346666', '1');
insert into momuser values('momuser7', 'example7@naver.com', '1230', '20170107', 'ktds', 'manager', '01012347777', '1');
insert into momuser values('momuser8', 'example8@naver.com', '1230', '20170108', 'ktds', 'manager', '01012348888', '1');
insert into momuser values('momuser9', 'example9@naver.com', '1230', '20170109', 'ktds', 'manager', '01012349999', '1');
insert into momuser values('momuser10', 'example10@naver.com', '1230', '20170110', 'ktds', 'manager', '01012340000', '0');
insert into momuser values('momuser11', 'example11@naver.com', '1230', '20170111', 'ktds', 'manager', '01012340001', '0');

commit;


